<!-- Bootstrap core JavaScript -->
<script src="<?php echo  SITE_URL; ?>view/js/jquery-3.5.1.min.js"></script>
<script src="<?php echo  SITE_URL; ?>view/js/bootstrap.js"></script>
<script src="<?php echo  SITE_URL; ?>view/js/bootstrap.bundle.min.js"></script> <!-- Menu Toggle Script -->
<script>
    $(function() {
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });

        $(window).resize(function(e) {
            if ($(window).width() <= 768) {
                $("#wrapper").removeClass("toggled");
            } else {
                $("#wrapper").addClass("toggled");
            }
        });
    });
</script>
</body>

</html>