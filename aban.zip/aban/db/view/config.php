<?php
define('DB_FILENAME', 'Myapp.data');


define('SITE_URL', 'http://localhost/aban/db');

define('SITE_PATH', __DIR__ . DIRECTORY_SEPARATOR);

define('APP_TITLE', 'شرکت تصفیه آب آبان');

//foreach (glob('lib/*.php') as $lib_file){
//    require_once($lib_file);
//}
if (function_exists('render_page')) {
  echo "sghl nkdi ";
}
