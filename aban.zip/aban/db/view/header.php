<html>

<head>
    <?php
    if (!function_exists('get_title')) {
        function get_title()
        {
            return APP_TITLE;;
        }
    }
    ?>
    <title><?php echo get_title() . "|" . APP_TITLE; ?></title>
    <link href="view/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="style.css" rel="stylesheet">
    <script src="view/js/jquery.min.js"></script>
</head>
<!------ Include the above in your HEAD tag ---------->

<body>

    <nav class="navbar navbar-expand navbar-dark bg-primary"> <a href="#menu-toggle" id="menu-toggle" class="navbar-brand"><span class="navbar-toggler-icon"></span></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample02" aria-controls="navbarsExample02" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
        <div class="collapse navbar-collapse" id="navbarsExample02">
            <img src="view/img/logo.jpg" alt=" logo " width="48px" height="48px" class="mx-auto">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active"> <a class="nav-link" href="#">خانه <span class="sr-only">(current)</span></a> </li>
                <li class="nav-item">
                    <div class="dropdown show ltr">
                        <a class="btn btn-info dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            پروفایل
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="#">مشخصات</a>
                            <a class="dropdown-item" href="#">پروفایل</a>
                            <a class="dropdown-item" href="#">خروج</a>
                        </div>
                    </div>
                </li>
            </ul>
            <form class="form-inline my-2 my-md-0"> </form>
        </div>
    </nav>