<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    html {
        direction: rtl;
    }
</style>

<body>
    <?php

    include_once('../../db.php');
    if (isset($_POST["name"])) {
        $name = $_POST["name"];
        $address = $_POST["address"];
        $tell = $_POST["tell"];
        $date = $_POST["date"];
    }
    if (!isset($_POST["name"]) == "" and !isset($_POST["address"]) == "" and !isset($_POST["tell"]) == "" and !isset($_POST["date"]) == "") {
        try {
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO server (name, address ,tell,date)
            VALUES ('$name', '$address','$tell','$date')";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "کاربر جدید  با موفقیت ایجاد شد";
        } catch (PDOException $e) {
            echo "$password,$username";
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn = null;
        echo "<a href=/aban/db/index.php>نمایش لیست</a>";
    } else {
        return 0;
    }
    ?>
</body>

</html>