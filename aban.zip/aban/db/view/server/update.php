<?php
if (isset($_POST["name"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $address = $_POST["address"];
    $tell = $_POST["tell"];
    $date = $_POST["date"];
}
if (!isset($_POST["name"]) == "" and !isset($_POST["address"]) == "" and !isset($_POST["tell"]) == "" and !isset($_POST["date"]) == "") {
    try {
        include_once('../../db.php');    // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE server SET name='$name',address='$address', tell= '$tell',date='$date' WHERE id='$id'";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // execute the query
        $stmt->execute();

        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully";
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
$conn = null;
echo "<a href=/aban/db/index.php>نمایش لیست</a>";
