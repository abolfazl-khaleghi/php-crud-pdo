<?php

if (isset($_POST["name"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $type = $_POST["type"];
    $many = $_POST["many"];
    $date = $_POST["date"];
}
if (!isset($name) == "" and !isset($type) == "" and !isset($many) == "" and !isset($date) == "") {
    try {
        include_once('../../db.php');    // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE sales SET name='$name',type='$type', many= '$many',date='$date' WHERE id='$id'";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // execute the query
        $stmt->execute();

        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully";
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
$conn = null;
echo "<a href=/aban/db/index.php?content_id=sales>نمایش لیست</a>";
