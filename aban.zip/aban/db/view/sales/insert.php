<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    html {
        direction: rtl;
    }
</style>

<body>
    <?php

    include_once('../../db.php');
    if (isset($_POST["name"])) {
        $name = $_POST["name"];
        $type = $_POST["type"];
        $many = $_POST["many"];
        $date = $_POST["date"];
    }
    if (!isset($name) == "" and !isset($type) == "" and !isset($many) == "" and !isset($date) == "") {
        try {
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO sales (name, type ,many,date)
            VALUES ('$name', '$type','$many','$date')";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "کاربر جدید  با موفقیت ایجاد شد";
        } catch (PDOException $e) {
            echo "$password,$username";
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn = null;
        echo "<a href=/aban/db/index.php?content_id=sales>نمایش لیست</a>";
    } else {
        return 0;
    }
    ?>
</body>

</html>