<?php
include_once('../../db.php');

if (isset($_POST["id"])) {
    $id = $_POST["id"];
}
if (!isset($_POST["id"]) == "") {

    try {
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // sql to delete a record
        $sql = "DELETE FROM sales WHERE id='$id'";

        // use exec() because no results are returned
        $conn->exec($sql);
        echo "عملیات حذف با موفقیت انجام شد";
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
} else {
    return 0;
}
echo "<a href=/aban/db/index.php?content_id=sales>نمایش لیست</a>";
$conn = null;
