<!-- Page Content -->
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <div class="card">
                    <div class="card-body">

                        <!--                        <div class="btn-group ltr" role="group" aria-label="Basic example">-->
                        <!--                            <button type="button" class="btn btn-primary"> ایجاد رکورد </button>-->
                        <!--                            <button type="button" class="btn btn-primary">نمایش لیست </button>-->
                        <!---->

                        <!--                        </div>-->
                        <!--                    </div>-->
                        <!--                </div>-->
                        <!--                <table class="table">-->
                        <!--                    <thead class="thead-dark">-->
                        <!--                    <tr>-->
                        <!--                        <th scope="col">#</th>-->
                        <!--                        <th scope="col">نام محصول</th>-->
                        <!--                        <th scope="col">مدل محصول</th>-->
                        <!--                        <th scope="col">قیمت </th>-->
                        <!--                    </tr>-->
                        <!--                    </thead>-->
                        <!--                    <tbody>-->
                        <!--                    <tr>-->
                        <!--                        <th scope="row">1</th>-->
                        <!--                        <td>تصفیه بتا</td>-->
                        <!--                        <td>m11</td>-->
                        <!--                        <td>900000 </td>-->
                        <!--                    </tr>-->
                        <!--                    <tr>-->
                        <!--                        <th scope="row">2</th>-->
                        <!--                        <td>تصفیه آلفا</td>-->
                        <!--                        <td>m24</td>-->
                        <!--                        <td>3000000</td>-->
                        <!--                    </tr>-->
                        <!--                    <tr>-->
                        <!--                        <th scope="row">3</th>-->
                        <!--                        <td>تصفیه تتا</td>-->
                        <!--                        <td>t57</td>-->
                        <!--                        <td>0</td>-->
                        <!--                    </tr>-->
                        <!--                    </tbody>-->
                        <!--                </table>-->
                        <!---->
                        <!---->
                        <!--            </div>-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--</div> -->
                        <!-- /#page-content-wrapper-->
                        <!-- /#wrapper -->