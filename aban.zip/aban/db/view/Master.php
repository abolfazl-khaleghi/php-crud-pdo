<?php

//include_once('user/index.php');
function Run_Function()
{
    include_once "view/header.php";
    include_once "view/sidebar.php";
    include_once "view/content.php";
    if ($_GET['content_id'] == "user") { 
        // crud user)(کاربران)
        include_once "user/index.php";
        include_once "user/update.php";
        include_once "user/create.html";
        selectUser();
        include_once "user/update.html";
        include_once "user/delete.html";
        //include_once "user/delete.php";
    } elseif ($_GET['content_id'] == "server") {

        // crud server(سرویس دهنده)
        include_once "server/index.php";
        include_once "server/update.php";
        include_once "server/create.html";
        selectserver();
        include_once "server/update.html";
        include_once "server/delete.html";
    } elseif ($_GET['content_id'] == "customers") {

        // crud customers(مشتریان)
        include_once "customers/index.php";
        include_once "customers/update.php";
        include_once "customers/create.html";
        selectcustomers();
        include_once "customers/update.html";
        include_once "customers/delete.html";
    } elseif ($_GET['content_id'] == "sales") {

        // crud sales(فروش)
        include_once "sales/index.php";
        include_once "sales/update.php";
        include_once "sales/create.html";
        selectsales();
        include_once "sales/update.html";
        include_once "sales/delete.html";
    }
    elseif ($_GET['content_id'] == "products") {

        // crud products(فروش)
        include_once "products/index.php";
        include_once "products/update.php";
        include_once "products/create.html";
        selectproducts();
        include_once "products/update.html";
        include_once "products/delete.html";
    }
    echo "</div></div></div></div></div>";
    //echo "<pre>";
    //var_dump($_SERVER);
    //echo "</pre>";
    include_once "view/footer.php";
}
