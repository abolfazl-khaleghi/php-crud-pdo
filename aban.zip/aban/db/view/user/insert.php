<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    html {
        direction: rtl;
    }
</style>

<body>
    <?php

    include_once('../../db.php');
    if (isset($_POST["Username"])) {
        $Username = $_POST["Username"];
        $password = $_POST["password"];
    }
    if (!isset($_POST["Username"]) == "" and !isset($_POST["password"]) == "") {
        try {
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO user (Username, password)
            VALUES ('$Username', '$password')";
            // use exec() because no results are returned
            $conn->exec($sql);
            echo "کاربر جدید  با موفقیت ایجاد شد";
        } catch (PDOException $e) {
            echo "$password,$username";
            echo $sql . "<br>" . $e->getMessage();
        }
        $conn = null;
        echo "<a href=/aban/db/index.php?content_id=user>نمایش لیست</a>";
    } else {
        return 0;
    }
    ?>
</body>

</html>