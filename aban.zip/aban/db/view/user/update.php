<?php
if (isset($_POST["Username"])) {
    $id = $_POST["id"];
    $Username = $_POST["Username"];
    $password = $_POST["password"];
}
if (!isset($_POST["Username"]) == "" and !isset($_POST["password"]) == "") {
    try {
        include_once('../../db.php');    // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE user SET Username='$Username', password='$password' WHERE id='$id'";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // execute the query
        $stmt->execute();

        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully";
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
$conn = null;
echo "<a href=/aban/db/index.php?content_id=user>نمایش لیست</a>";
