<div id="wrapper" class="toggled">
    <!-- Sidebar -->
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand"> <a href="#"> داشبورد شرکت آبان</a> </li>
            <li> <a href="#">Dashboard</a> </li>
            <li> <a href="index.php?content_id=sales"> فروش</a> </li>
            <li> <a href="index.php?content_id=products"> محصولات </a> </li>
            <li> <a href="index.php?content_id=user"> کاربران</a> </li>
            <li> <a href="index.php?content_id=customers">مشتریان </a> </li>
            <li> <a href="index.php?content_id=server">سرویس دهنده </a> </li>
        </ul>
    </div>
    <!-- sidebar-wrapper -->