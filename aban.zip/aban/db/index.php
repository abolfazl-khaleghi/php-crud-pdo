<?php
include_once('view/Master.php');
//include_once "view/modles/login/login.php";
//include_once('view/config.php');
Run_Function();
